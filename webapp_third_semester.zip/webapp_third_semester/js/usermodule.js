export default class User {
  constructor(name) {
    this.name = name;
  }
}
